<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Admin — {{ config('app.name') }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @php do_action('admin_head'); @endphp
    <style>
        body {
            font-family: system-ui, -apple-system, Segoe UI, Roboto;
            background: #f7f7f8
        }

        .wrap {
            max-width: 1200px;
            margin: 24px auto;
            padding: 0 16px;
            display: grid;
            grid-template-columns: 220px 1fr;
            gap: 24px
        }

        .card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 6px 24px rgba(0, 0, 0, .06)
        }

        .sidebar a {
            display: block;
            padding: 10px 12px;
            border-radius: 10px;
            text-decoration: none;
            color: #111827
        }

        .sidebar a:hover {
            background: #f3f4f6
        }

        .top {
            padding: 16px
        }

        .content {
            padding: 16px
        }
    </style>
</head>

<body>
    <div class="wrap">
        <aside class="card sidebar">
            <div class="top"><strong>Admin</strong></div>
            <nav class="content">
                <a href="{{ route('admin.dashboard') }}">🏠 Dashboard</a>
                {{-- Module/CPT links via filter (works today) --}}
                {!! apply_filters('admin_sidebar_menu', '') !!}
            </nav>
            <form method="post" action="{{ route('logout') }}" style="padding:16px">
                @csrf
                <button type="submit"
                    style="background:#111827;color:#fff;border:0;padding:8px 12px;border-radius:10px;cursor:pointer">Logout</button>
            </form>
        </aside>
        <section class="card" style="padding:16px">
            @yield('content')
        </section>
    </div>
    @php do_action('admin_footer'); @endphp
</body>

</html>
