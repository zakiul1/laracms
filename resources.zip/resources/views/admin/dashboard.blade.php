@extends('admin.layout')

@section('content')
    <h1 style="font-size:20px;font-weight:600;margin-bottom:12px">Dashboard</h1>

    <div style="display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(260px,1fr))">
        @php do_action('admin_dashboard_cards'); @endphp
        <div class="card" style="padding:16px">
            <h3 style="margin:0 0 8px">Welcome</h3>
            <p>Phase 0 admin is secured by Breeze + is_admin. Modules can inject cards & menu links.</p>
        </div>
    </div>
@endsection
